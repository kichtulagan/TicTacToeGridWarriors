import pygame
import sys
import random

pygame.init()

screen_size = (700, 700)
screen = pygame.display.set_mode(screen_size)
pygame.display.set_caption("TicTacToe Grid Warriors")

# Load images
mainscreen = pygame.image.load("mainscreen.png")
nextscreen = pygame.image.load("nextscreen.png")
pvpscreen = pygame.image.load("pvpscreen.png")
versusboto = pygame.image.load("versusboto.png")
backbtn = pygame.image.load("backbtn.png")

# Load buttons
play_button = pygame.image.load("playbtn.png")
quit_button = pygame.image.load("quitbtn.png")
pvpbtn = pygame.image.load("pvpbtn.png")
botbtn = pygame.image.load("botbtn.png")

# Resize buttons to fit the GUI
play_button = pygame.transform.scale(play_button, (150, 75))
quit_button = pygame.transform.scale(quit_button, (150, 75))
pvpbtn = pygame.transform.scale(pvpbtn, (150, 75))
botbtn = pygame.transform.scale(botbtn, (150, 75))
backbtn = pygame.transform.scale(backbtn, (150, 75))

# Button positions
play_button_rect = play_button.get_rect(center=(screen_size[0] / 2, screen_size[1] / 2 - 50))
quit_button_rect = quit_button.get_rect(center=(screen_size[0] / 2, screen_size[1] / 2 + 50))
pvpbtn_rect = pvpbtn.get_rect(center=(screen_size[0] / 2 - 100, screen_size[1] / 2))
botbtn_rect = botbtn.get_rect(center=(screen_size[0] / 2 + 100, screen_size[1] / 2))
backbtn_rect_pvp = backbtn.get_rect(center=(screen_size[0] / 2.9 + 100, screen_size[1] / 1.9 + 300))
backbtn_rect_next = backbtn.get_rect(center=(screen_size[0] / 2, screen_size[1] / 2 + 200))

# Screen state variable
current_screen = "main"

# Tic Tac Toe Game Variables
board = [[' ' for _ in range(3)] for _ in range(3)]
player_turn = 'X'
game_over = False
player1_score = 0
player2_score = 0

# Colors
black = (0, 0, 0)
white = (255, 255, 255)
red = (255, 0, 0)
blue = (0, 0, 255)
draw_color = (237, 171, 18)

# Load Anton font
anton_font = pygame.font.Font("Anton-Regular.ttf", 36)
anton_font_large = pygame.font.Font("Anton-Regular.ttf", 48)

# Adjusted dimensions for a centered and smaller board
box_size = 100
board_start_x = (screen_size[0] - box_size * 3) // 2
board_start_y = (screen_size[1] - box_size * 3) // 2

# Function to draw the Tic Tac Toe board
def draw_board():
    for i in range(3):
        for j in range(3):
            rect = pygame.Rect(board_start_x + j * box_size, board_start_y + i * box_size, box_size, box_size)
            pygame.draw.rect(screen, white, rect, 7)

# Function to draw the X and O
def draw_xo(row, col):
    rect = pygame.Rect(board_start_x + col * box_size + 10, board_start_y + row * box_size + 10, box_size - 20, box_size - 20)
    if board[row][col] == 'X':
        pygame.draw.line(screen, red, (rect.left, rect.top), (rect.right, rect.bottom), 15)
        pygame.draw.line(screen, red, (rect.right, rect.top), (rect.left, rect.bottom), 15)
    elif board[row][col] == 'O':
        pygame.draw.circle(screen, blue, rect.center, (box_size - 20) // 2, 10)

# Function to check for a win
def check_win():
    # Check rows
    for i in range(3):
        if board[i][0] == board[i][1] == board[i][2] and board[i][0] != ' ':
            return board[i][0]

    # Check columns
    for j in range(3):
        if board[0][j] == board[1][j] == board[2][j] and board[0][j] != ' ':
            return board[0][j]

    # Check diagonals
    if board[0][0] == board[1][1] == board[2][2] and board[0][0] != ' ':
        return board[0][0]
    if board[0][2] == board[1][1] == board[2][0] and board[0][2] != ' ':
        return board[0][2]

    # Check for a draw
    for i in range(3):
        for j in range(3):
            if board[i][j] == ' ':
                return None
    return 'Draw'

# Function to reset the game
def reset_game():
    global board, player_turn, game_over
    board = [[' ' for _ in range(3)] for _ in range(3)]
    player_turn = 'X'
    game_over = False

# Function to draw the winning line
def draw_winning_line(winner):
    line_width = 10
    if winner == 'X':
        line_color = red
    else:
        line_color = blue

    # Check rows
    for i in range(3):
        if board[i][0] == board[i][1] == board[i][2] and board[i][0] != ' ':
            pygame.draw.line(screen, line_color,
                             (board_start_x, board_start_y + i * box_size + box_size // 2),
                             (board_start_x + box_size * 3, board_start_y + i * box_size + box_size // 2),
                             line_width)
            return

    # Check columns
    for j in range(3):
        if board[0][j] == board[1][j] == board[2][j] and board[0][j] != ' ':
            pygame.draw.line(screen, line_color,
                             (board_start_x + j * box_size + box_size // 2, board_start_y),
                             (board_start_x + j * box_size + box_size // 2, board_start_y + box_size * 3),
                             line_width)
            return

    # Check diagonals
    if board[0][0] == board[1][1] == board[2][2] and board[0][0] != ' ':
        pygame.draw.line(screen, line_color,
                             (board_start_x, board_start_y),
                             (board_start_x + box_size * 3, board_start_y + box_size * 3),
                             line_width)
        return
    if board[0][2] == board[1][1] == board[2][0] and board[0][2] != ' ':
        pygame.draw.line(screen, line_color,
                             (board_start_x + box_size * 3, board_start_y),
                             (board_start_x, board_start_y + box_size * 3),
                             line_width)
        return

# AI (Minimax Algorithm)
def minimax(board, depth, is_maximizing):
    winner = check_win()
    if winner:
        if winner == 'X':
            return -10 + depth
        elif winner == 'O':
            return 10 - depth
        else:
            return 0

    if is_maximizing:
        best_score = -float('inf')
        for i in range(3):
            for j in range(3):
                if board[i][j] == ' ':
                    board[i][j] = 'O'
                    score = minimax(board, depth + 1, False)
                    board[i][j] = ' '
                    best_score = max(score, best_score)
        return best_score
    else:
        best_score = float('inf')
        for i in range(3):
            for j in range(3):
                if board[i][j] == ' ':
                    board[i][j] = 'X'
                    score = minimax(board, depth + 1, True)
                    board[i][j] = ' '
                    best_score = min(score, best_score)
        return best_score

# Function for the AI to make a move
def bot_move():
    best_score = -float('inf')
    best_move = (-1, -1)
    for i in range(3):
        for j in range(3):
            if board[i][j] == ' ':
                board[i][j] = 'O'
                score = minimax(board, 0, False)
                board[i][j] = ' '
                if score > best_score:
                    best_score = score
                    best_move = (i, j)
    board[best_move[0]][best_move[1]] = 'O'

# Game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            x, y = event.pos
            if current_screen == "main":
                if play_button_rect.collidepoint(event.pos):
                    current_screen = "next"
                if quit_button_rect.collidepoint(event.pos):
                    running = False
            elif current_screen == "next":
                if pvpbtn_rect.collidepoint(event.pos):
                    current_screen = "pvp"
                    # Reset scores when switching to PVP
                    player1_score = 0
                    player2_score = 0
                if botbtn_rect.collidepoint(event.pos):
                    current_screen = "versusbot"
                    # Reset scores when switching to versus BOT
                    player1_score = 0
                    player2_score = 0
                if backbtn_rect_next.collidepoint(event.pos):
                    current_screen = "main"
            elif current_screen == "pvp" and not game_over:
                col = (x - board_start_x) // box_size
                row = (y - board_start_y) // box_size
                if 0 <= col <= 2 and 0 <= row <= 2 and board[row][col] == ' ':
                    board[row][col] = player_turn
                    player_turn = 'O' if player_turn == 'X' else 'X'
            elif current_screen == "versusbot" and not game_over and player_turn == 'X':
                col = (x - board_start_x) // box_size
                row = (y - board_start_y) // box_size
                if 0 <= col <= 2 and 0 <= row <= 2 and board[row][col] == ' ':
                    board[row][col] = player_turn
                    player_turn = 'O'
            if backbtn_rect_pvp.collidepoint(event.pos) and current_screen == "pvp":
                current_screen = "next"
            if backbtn_rect_pvp.collidepoint(event.pos) and current_screen == "versusbot":
                current_screen = "next"

    # Check for win or draw
    winner = check_win()
    if winner:
        game_over = True

        # Update the score based on the winner
        if winner == 'X':
            player1_score += 1
        elif winner == 'O':
            player2_score += 1

    # Render the current screen based on state
    if current_screen == "main":
        screen.blit(mainscreen, (0, 0))
        screen.blit(play_button, play_button_rect)
        screen.blit(quit_button, quit_button_rect)
    elif current_screen == "next":
        screen.blit(nextscreen, (0, 0))
        screen.blit(pvpbtn, pvpbtn_rect)
        screen.blit(botbtn, botbtn_rect)
        screen.blit(backbtn, backbtn_rect_next)
    elif current_screen == "pvp":
        screen.blit(pvpscreen, (0, 0))
        screen.blit(backbtn, backbtn_rect_pvp)

        # Draw the game board
        draw_board()

        # Draw the X and O on the board
        for i in range(3):
            for j in range(3):
                draw_xo(i, j)

        # Display score using Anton font in different colors
        player1_text = anton_font.render(f"{player1_score}", True, red)
        vs_text = anton_font.render("                              ", True, white)
        player2_text = anton_font.render(f"{player2_score}", True, blue)

        # Calculate the total width of the text to center it
        total_width = player1_text.get_width() + vs_text.get_width() + player2_text.get_width()

        # Calculate positions for each part
        player1_pos = (screen_size[0] // 2 - total_width // 2, board_start_y - 55)
        vs_pos = (player1_pos[0] + player1_text.get_width(), board_start_y - 55)
        player2_pos = (vs_pos[0] + vs_text.get_width(), board_start_y - 55)

        # Render the text parts on the screen
        screen.blit(player1_text, player1_pos)
        screen.blit(vs_text, vs_pos)
        screen.blit(player2_text, player2_pos)

        # Display game over message using Anton font with appropriate color
        if game_over:
            if winner == 'Draw':
                game_over_text = anton_font_large.render("DRAW!", True, draw_color)
            elif winner == 'X':
                game_over_text = anton_font_large.render(f"PLAYER {winner} WON", True, red)
            else:
                game_over_text = anton_font_large.render(f"PLAYER {winner} WON", True, blue)

            # Calculate the width of the text
            text_width = game_over_text.get_width()

            # Calculate the x-position to center the text
            x_pos = (screen_size[0] - text_width) // 2

            # Render the text
            screen.blit(game_over_text, (x_pos, board_start_y + box_size * 3 + 30))

            # Draw the winning line
            draw_winning_line(winner)
    elif current_screen == "versusbot":
        screen.blit(versusboto, (0, 0))
        screen.blit(backbtn, backbtn_rect_pvp)

        # Draw the game board
        draw_board()

        # Draw the X and O on the board
        for i in range(3):
            for j in range(3):
                draw_xo(i, j)

        # Display score using Anton font in different colors
        player1_text = anton_font.render(f"{player1_score}", True, red)
        vs_text = anton_font.render("                              ", True, white)
        player2_text = anton_font.render(f"{player2_score}", True, blue)


        total_width = player1_text.get_width() + vs_text.get_width() + player2_text.get_width()


        player1_pos = (screen_size[0] // 2 - total_width // 2, board_start_y - 55)
        vs_pos = (player1_pos[0] + player1_text.get_width(), board_start_y - 55)
        player2_pos = (vs_pos[0] + vs_text.get_width(), board_start_y - 55)


        screen.blit(player1_text, player1_pos)
        screen.blit(vs_text, vs_pos)
        screen.blit(player2_text, player2_pos)

        # DISPLAY MESSAGE using ANTON FONT
        if game_over:
            if winner == 'Draw':
                game_over_text = anton_font_large.render("DRAW", True, draw_color)
            elif winner == 'X':
                game_over_text = anton_font_large.render("YOU WON", True, red)
            else:
                game_over_text = anton_font_large.render("BOT WON", True, blue)


            text_width = game_over_text.get_width()


            x_pos = (screen_size[0] - text_width) // 2


            screen.blit(game_over_text, (x_pos, board_start_y + box_size * 3 + 30))

            # Slash line Winning Line
            draw_winning_line(winner)

        # BOT Turn
        if player_turn == 'O' and not game_over:
            pygame.time.wait(50) # Pause for a moment to simulate thinking
            bot_move()
            player_turn = 'X'  # Switch back to player's turn

    pygame.display.flip()

    if game_over:
        pygame.time.wait(2000)  # Wait for 2 seconds before resetting
        reset_game()

pygame.quit()
sys.exit()